# قصر الأميرات — Qasr Al Amirat

A luxury Arabic abaya boutique, built right-to-left from the ground up. Visitors browse
eight abaya designs, pick a size and colour, add pieces to a persistent cart, and complete
the order over WhatsApp — no payment gateway or account required.

## What's in the store

| Screen | Path | What it does |
|--------|------|--------------|
| Homepage | `/` | Logo and crest, hero, brand promises, featured abayas, atelier story, customer voices, WhatsApp contact section |
| Gallery | `/products` | All eight abayas with images, prices, sizes and colour swatches, category filters, price sorting, size guide |
| Product page | `/products/$productId` | Large arched photo, full description, fabric/care details, size + colour + quantity pickers, add to cart, WhatsApp order, related pieces |
| Cart | `/cart` | Line items, quantity steppers, subtotal, free-shipping threshold, WhatsApp checkout, how-it-works steps |

A slide-in cart drawer, a floating WhatsApp button, and Arabic not-found/error screens are
available on every page.

## Tech stack

- **TanStack Start** (React 19 + TanStack Router, file-based routing, SSR)
- **Tailwind CSS 4** — theme tokens for the burgundy/black/gold palette live in `src/styles.css`
- **Arabic typography** — Amiri (display), Reem Kufi (UI labels), Tajawal (body)
- **Netlify Image CDN** — product photography is transformed on the edge to WebP
- **Netlify AI Gateway** — the product photography in `public/img` was generated with a Gemini image model via `scripts/generate-images.mjs`
- Cart state: React context + `localStorage`, no backend

## Before going live

Open `src/lib/store.ts` and replace the placeholder contact details with the boutique's real
ones — most importantly `whatsapp` (full international format, digits only, e.g. `9665XXXXXXXX`)
and `whatsappDisplay`. Every order button, the drawer checkout and the contact links are built
from that single value. Prices, currency, and the free-shipping threshold live in the same file;
the catalogue itself is `src/data/products.ts`.

## Run locally

```bash
pnpm install
netlify dev --port 8889   # recommended: emulates the Image CDN used for product photos
# or: pnpm dev            # plain Vite on :3000 (product images will not transform)
```

## Roadmap

1. **Done** — storefront: homepage, gallery, product pages, cart, WhatsApp ordering, RTL Arabic UI.
2. A dedicated `/contact` page with the showroom map, opening hours and a booking form (the
   homepage contact section and footer already carry every detail; the header links ahead to it).
3. Order records in Netlify DB so WhatsApp orders can be logged and tracked.
4. An owner area for editing the catalogue and stock without code changes.
