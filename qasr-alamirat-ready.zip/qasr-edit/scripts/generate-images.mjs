/**
 * Generates the store's product photography with a Gemini image model through
 * Netlify AI Gateway. Run once to populate public/img:
 *
 *   node scripts/generate-images.mjs
 *
 * Images are served to visitors through the Netlify Image CDN, so the large
 * originals never ship to the browser.
 */
import { GoogleGenAI } from '@google/genai'
import { writeFile } from 'node:fs/promises'

const ai = new GoogleGenAI({
  apiKey: process.env.NETLIFY_AI_GATEWAY_KEY,
  httpOptions: { baseUrl: process.env.NETLIFY_AI_GATEWAY_BASE_URL?.replace(/\/$/, '') },
})

const LOOK =
  'Luxury modest-fashion editorial photography. Full-length abaya shown on an elegant ' +
  'faceless matte mannequin in a softly lit studio. Deep burgundy, black and warm gold ' +
  'palette, marble and dark velvet surfaces, soft golden rim light, subtle shadows, ' +
  'shallow depth of field, rich fabric texture visible. Vertical 3:4 framing, centered, ' +
  'generous negative space. No text, no letters, no logos, no watermarks, no human face.'

const IMAGES = [
  {
    file: 'hero.png',
    prompt:
      'Luxury abaya boutique hero image: three elegant abayas in black, deep burgundy and ' +
      'champagne gold displayed on slim faceless mannequins in a palace-like showroom with ' +
      'arched Islamic-style niches, marble floor, brass lanterns and dark velvet drapes. ' +
      'Cinematic warm golden lighting, wide horizontal 16:9 composition. No text, no letters, ' +
      'no logos, no watermarks, no human face.',
  },
  {
    file: 'abaya-laylat-al-amir.png',
    prompt: `${LOOK} A flowing burgundy velvet abaya with delicate gold thread embroidery along the front placket and cuffs.`,
  },
  {
    file: 'abaya-naseem-al-harir.png',
    prompt: `${LOOK} A minimal jet-black silk-crepe abaya with a clean straight cut and softly draped wide sleeves.`,
  },
  {
    file: 'abaya-taj-al-dhahab.png',
    prompt: `${LOOK} A black abaya with ornate gold-embroidered sleeve panels and a subtle gold trim at the neckline.`,
  },
  {
    file: 'abaya-hams-al-anbar.png',
    prompt: `${LOOK} A champagne-beige nida abaya with tonal satin piping and a slim matching belt tied at the waist.`,
  },
  {
    file: 'abaya-zilal-al-layl.png',
    prompt: `${LOOK} A finely pleated black abaya with an airy accordion-pleat skirt that catches the light.`,
  },
  {
    file: 'abaya-yaqut.png',
    parts: 1,
    prompt: `${LOOK} A deep ruby-burgundy crepe abaya with a wrap front and a wide self-fabric belt.`,
  },
  {
    file: 'abaya-luluu.png',
    prompt: `${LOOK} An off-white pearl-toned abaya with a row of small pearl buttons down the front and pearl-beaded cuffs.`,
  },
  {
    file: 'abaya-sundus.png',
    prompt: `${LOOK} An open kimono-style black abaya with sweeping gold botanical embroidery across the hem and sleeve edges, worn over a burgundy inner dress.`,
  },
]

async function generate({ file, prompt }) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-image',
        contents: prompt,
      })
      const parts = response.candidates?.[0]?.content?.parts ?? []
      const image = parts.find((part) => part.inlineData)
      if (!image) throw new Error('no image part returned')
      await writeFile(`public/img/${file}`, Buffer.from(image.inlineData.data, 'base64'))
      console.log(`ok   ${file}`)
      return
    } catch (error) {
      console.log(`warn ${file} attempt ${attempt}: ${error.message}`)
      if (attempt === 3) console.log(`FAIL ${file}`)
      else await new Promise((resolve) => setTimeout(resolve, 4000 * attempt))
    }
  }
}

const queue = [...IMAGES]
await Promise.all(
  Array.from({ length: 3 }, async () => {
    while (queue.length) await generate(queue.shift())
  }),
)
console.log('done')
