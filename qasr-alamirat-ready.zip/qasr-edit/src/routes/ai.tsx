import { createFileRoute, Link } from '@tanstack/react-router'
import { useMemo, useState } from 'react'
import { ArrowRight, Clapperboard, Copy, Download, ImagePlus, Sparkles } from 'lucide-react'

export const Route = createFileRoute('/ai')({ component: AiStudioPage })

function AiStudioPage() {
  const [file, setFile] = useState<File | null>(null)
  const [style, setStyle] = useState('luxury')
  const [duration, setDuration] = useState('8')
  const [movement, setMovement] = useState('slow walk toward camera')
  const [copied, setCopied] = useState(false)
  const preview = useMemo(() => file ? URL.createObjectURL(file) : '', [file])
  const prompt = `Create a ${duration}-second vertical 9:16 luxury fashion video using the uploaded abaya photo as the exact reference. Style: ${style === 'luxury' ? 'cinematic luxury boutique, soft violet and silver lighting, elegant palace background' : style === 'minimal' ? 'clean minimalist studio, soft neutral lighting' : 'social-media fashion campaign, rich dramatic lighting'}. Motion: ${movement}. Preserve the exact abaya design, color, embroidery, fabric and model identity; do not add text, logos, accessories, or alter the garment. Smooth realistic motion, high detail, premium product advertisement.`
  async function copyPrompt() {
    try { await navigator.clipboard.writeText(prompt); setCopied(true); window.setTimeout(() => setCopied(false), 1800) } catch { setCopied(false) }
  }
  function downloadPrompt() {
    const blob = new Blob([prompt], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = 'qasr-alamirat-video-prompt.txt'
    anchor.click()
    URL.revokeObjectURL(url)
  }
  return <main className="mx-auto max-w-5xl px-4 py-10 md:px-6">
    <Link to="/" className="mb-6 inline-flex items-center gap-2 text-sm text-gold-200"><ArrowRight className="h-4 w-4"/> العودة للرئيسية</Link>
    <div className="mb-8 flex items-center gap-3"><span className="rounded-full border border-gold-400/40 p-3 text-gold-200"><Sparkles/></span><div><p className="font-kufi text-xs text-gold-200">قصر الأميرات</p><h1 className="font-display text-3xl text-sand md:text-4xl">استوديو AI للعبايات</h1><p className="mt-2 text-sm text-mist">جهّزي صورة العباية وبرومبت فيديو مخصص لها، وانسخيه أو احفظيه لاستخدامه بأداة توليد الفيديو.</p></div></div>
    <div className="grid gap-6 md:grid-cols-2">
      <section className="panel rounded-2xl p-5">
        <h2 className="mb-4 flex items-center gap-2 font-kufi text-lg text-gold-100"><ImagePlus className="h-5 w-5"/> صورة العباية</h2>
        <label className="flex min-h-64 cursor-pointer flex-col items-center justify-center overflow-hidden rounded-xl border border-dashed border-gold-400/40 bg-ink/50 text-center">
          {preview ? <img src={preview} alt="معاينة صورة العباية" className="max-h-96 w-full object-contain"/> : <><ImagePlus className="mb-3 h-10 w-10 text-gold-200"/><span className="font-kufi text-sand">اضغطي لاختيار صورة</span><span className="mt-2 text-xs text-mist">JPG أو PNG أو WEBP</span></>}
          <input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={e => setFile(e.target.files?.[0] ?? null)}/>
        </label>
        {file && <p className="mt-3 truncate text-xs text-mist">{file.name}</p>}
        <label className="mt-5 block text-sm text-sand">ستايل الفيديو</label>
        <select value={style} onChange={e => setStyle(e.target.value)} className="mt-2 w-full rounded-lg border border-gold-400/30 bg-ink p-3 text-sand"><option value="luxury">فاخر بنفسجي وقصر</option><option value="minimal">استوديو بسيط</option><option value="social">إعلان ترندي</option></select>
        <label className="mt-5 block text-sm text-sand">مدة الفيديو</label>
        <select value={duration} onChange={e => setDuration(e.target.value)} className="mt-2 w-full rounded-lg border border-gold-400/30 bg-ink p-3 text-sand"><option value="5">٥ ثواني</option><option value="8">٨ ثواني</option><option value="10">١٠ ثواني</option><option value="15">١٥ ثانية</option></select>
        <label className="mt-5 block text-sm text-sand">حركة المشهد</label>
        <select value={movement} onChange={e => setMovement(e.target.value)} className="mt-2 w-full rounded-lg border border-gold-400/30 bg-ink p-3 text-sand"><option value="slow walk toward camera">مشي بطيء باتجاه الكاميرا</option><option value="gentle turn showing the abaya details">دوران خفيف لإظهار التفاصيل</option><option value="subtle fabric movement with a slow camera push-in">حركة قماش ناعمة وتقريب الكاميرا</option><option value="opening an elegant palace door and walking in">فتح باب القصر والمشي للداخل</option></select>
      </section>
      <section className="panel rounded-2xl p-5">
        <h2 className="mb-4 flex items-center gap-2 font-kufi text-lg text-gold-100"><Clapperboard className="h-5 w-5"/> برومبت الفيديو</h2>
        <p className="mb-4 text-sm leading-7 text-mist">هذا النص جاهز للنسخ إلى أداة توليد فيديو تدعم تحويل الصورة إلى فيديو.</p>
        <div dir="ltr" className="min-h-52 whitespace-pre-wrap rounded-xl border border-gold-400/20 bg-ink/70 p-4 text-sm leading-6 text-sand">{prompt}</div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2"><button type="button" onClick={copyPrompt} className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-l from-gold-600 via-gold-400 to-gold-300 px-5 py-3 font-kufi font-bold text-wine-950"><Copy className="h-4 w-4"/>{copied ? 'تم النسخ' : 'انسخي البرومبت'}</button><button type="button" onClick={downloadPrompt} className="flex w-full items-center justify-center gap-2 rounded-full border border-gold-300/40 px-5 py-3 font-kufi text-gold-100 transition hover:bg-gold-400/10"><Download className="h-4 w-4"/>احفظي البرومبت TXT</button></div>
        <div className="mt-5 rounded-xl border border-gold-400/20 p-4 text-xs leading-6 text-mist"><strong className="text-gold-100">ملاحظة مهمة:</strong> هذه النسخة تجهّز البرومبت ومعاينة الصورة داخل الموقع؛ توليد ملف فيديو بالذكاء الاصطناعي مباشرة يحتاج ربط API لخدمة فيديو ومفتاح API آمن على الخادم. لم يتم تفعيل توليد الفيديو الحقيقي بعد.</div>
      </section>
    </div>
  </main>
}
