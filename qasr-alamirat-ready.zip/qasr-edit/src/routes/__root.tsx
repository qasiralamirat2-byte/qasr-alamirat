import {
  HeadContent,
  Link,
  Scripts,
  createRootRoute,
} from '@tanstack/react-router'
import { Ornament, WhatsAppIcon } from '@/components/Brand'
import { CartDrawer } from '@/components/CartDrawer'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { CartProvider } from '@/lib/cart'
import { STORE, WHATSAPP_GREETING, whatsappLink } from '@/lib/store'
import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: `${STORE.name} | عبايات فاخرة — ${STORE.nameLatin}` },
      {
        name: 'description',
        content:
          'قصر الأميرات — متجر عبايات فاخرة: مخمل مطرز، كريب، بليسيه وكيمونو. اختاري المقاس واللون واطلبي مباشرة عبر واتساب مع توصيل لجميع مناطق المملكة.',
      },
      { name: 'theme-color', content: '#200610' },
      { property: 'og:title', content: `${STORE.name} — ${STORE.tagline}` },
      { property: 'og:type', content: 'website' },
      { property: 'og:locale', content: 'ar_SA' },
    ],
    links: [
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      {
        rel: 'preconnect',
        href: 'https://fonts.gstatic.com',
        crossOrigin: 'anonymous',
      },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Reem+Kufi:wght@400..700&family=Tajawal:wght@300;400;500;700&display=swap',
      },
      { rel: 'icon', href: '/favicon.ico' },
    ],
  }),
  shellComponent: RootDocument,
  errorComponent: ErrorScreen,
  notFoundComponent: NotFoundScreen,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <HeadContent />
      </head>
      <body>
        <CartProvider>
          <Header />
          <main>{children}</main>
          <Footer />
          <CartDrawer />
          <FloatingWhatsApp />
        </CartProvider>
        <Scripts />
      </body>
    </html>
  )
}

function FloatingWhatsApp() {
  return (
    <a
      href={whatsappLink(WHATSAPP_GREETING)}
      target="_blank"
      rel="noreferrer noopener"
      aria-label="تواصلي معنا على واتساب"
      className="fixed bottom-5 end-5 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-[#1f6b4f] text-white shadow-lift ring-1 ring-gold-300/40 transition-transform hover:scale-105"
    >
      <WhatsAppIcon className="h-7 w-7" />
    </a>
  )
}

/** Shown instead of a blank page if a route ever fails. */
function ErrorScreen({ error }: { error: Error }) {
  return (
    <Fallback
      title="حدث خطأ غير متوقع"
      body="نأسف على ذلك. يمكنك إعادة تحميل الصفحة أو العودة إلى الرئيسية، ونحن جاهزون لمساعدتك على واتساب."
      detail={error.message}
    />
  )
}

function NotFoundScreen() {
  return (
    <Fallback
      title="الصفحة غير موجودة"
      body="ربما تغيّر رابط هذه الصفحة. تفضّلي بالعودة إلى المعرض لاستعراض جميع العبايات المتوفرة."
    />
  )
}

function Fallback({
  title,
  body,
  detail,
}: {
  title: string
  body: string
  detail?: string
}) {
  return (
    <section className="mx-auto flex min-h-[60vh] max-w-xl flex-col items-center justify-center px-6 py-20 text-center">
      <h1 className="gold-text font-display text-3xl md:text-4xl">{title}</h1>
      <Ornament className="my-6" />
      <p className="leading-relaxed text-mist">{body}</p>
      {detail && (
        <p className="mt-4 max-w-md rounded-lg border border-gold-500/20 bg-night/70 px-4 py-2 text-xs text-mist/80" dir="auto">
          {detail}
        </p>
      )}
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        <Link
          to="/"
          className="rounded-full border border-gold-400/50 px-6 py-3 font-kufi text-sm text-gold-200 transition-colors hover:bg-gold-400/10"
        >
          العودة إلى الرئيسية
        </Link>
        <Link
          to="/products"
          className="rounded-full bg-wine-700 px-6 py-3 font-kufi text-sm text-sand transition-colors hover:bg-wine-600"
        >
          تصفّحي المعرض
        </Link>
      </div>
    </section>
  )
}
