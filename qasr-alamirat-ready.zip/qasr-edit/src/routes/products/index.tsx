import { useMemo, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { SlidersHorizontal } from 'lucide-react'
import { Ornament } from '@/components/Brand'
import { ProductCard } from '@/components/ProductCard'
import products, { CATEGORIES, SIZE_GUIDE } from '@/data/products'
import type { Category } from '@/data/products'
import { STORE, formatPrice } from '@/lib/store'

export const Route = createFileRoute('/products/')({
  component: GalleryPage,
})

type SortKey = 'مميزة' | 'الأقل سعرًا' | 'الأعلى سعرًا'
const SORTS: Array<SortKey> = ['مميزة', 'الأقل سعرًا', 'الأعلى سعرًا']

function GalleryPage() {
  const [category, setCategory] = useState<Category>('الكل')
  const [sort, setSort] = useState<SortKey>('مميزة')

  const visible = useMemo(() => {
    const filtered =
      category === 'الكل'
        ? [...products]
        : products.filter((product) => product.category === category)

    if (sort === 'الأقل سعرًا') return filtered.sort((a, b) => a.price - b.price)
    if (sort === 'الأعلى سعرًا') return filtered.sort((a, b) => b.price - a.price)
    return filtered.sort(
      (a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)),
    )
  }, [category, sort])

  return (
    <section className="mx-auto max-w-7xl px-4 py-12 md:px-6 md:py-16">
      <header className="text-center">
        <p className="font-kufi text-xs text-gold-400">معرض العبايات</p>
        <h1 className="mt-3 font-display text-3xl md:text-5xl">
          <span className="gold-text">مجموعة {STORE.name}</span>
        </h1>
        <Ornament className="mt-5" />
        <p className="mx-auto mt-6 max-w-2xl leading-loose text-mist">
          كل تصميم متوفر بعدة مقاسات وألوان. حدّدي مقاسك ولونك من البطاقة نفسها،
          ثم أضيفيها إلى السلة أو أرسليها مباشرة على واتساب.
        </p>
      </header>

      {/* Filters */}
      <div className="panel mt-10 flex flex-col gap-4 rounded-2xl p-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <span className="me-1 flex items-center gap-1.5 font-kufi text-xs text-mist">
            <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
            التصنيف
          </span>
          {CATEGORIES.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => setCategory(option)}
              aria-pressed={category === option}
              className={`rounded-full border px-4 py-2 font-kufi text-xs transition-colors ${
                category === option
                  ? 'border-gold-300 bg-gold-400/15 text-gold-100'
                  : 'border-gold-500/25 text-mist hover:border-gold-400/60 hover:text-sand'
              }`}
            >
              {option}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="me-1 font-kufi text-xs text-mist">الترتيب</span>
          {SORTS.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => setSort(option)}
              aria-pressed={sort === option}
              className={`rounded-full border px-4 py-2 font-kufi text-xs transition-colors ${
                sort === option
                  ? 'border-gold-300 bg-gold-400/15 text-gold-100'
                  : 'border-gold-500/25 text-mist hover:border-gold-400/60 hover:text-sand'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      <p className="mt-5 font-kufi text-xs text-mist">
        {visible.length.toLocaleString('ar-SA')} تصميم متوفر
        {category !== 'الكل' && ` في تصنيف «${category}»`}
      </p>

      {visible.length === 0 ? (
        <div className="panel mt-8 rounded-2xl px-6 py-16 text-center">
          <p className="font-display text-xl text-sand">لا توجد قطع في هذا التصنيف حاليًا</p>
          <p className="mt-3 text-sm text-mist">
            جرّبي تصنيفًا آخر، أو راسلينا على واتساب لنخبرك بموعد وصول الدفعة القادمة.
          </p>
          <button
            type="button"
            onClick={() => setCategory('الكل')}
            className="mt-6 rounded-full border border-gold-400/50 px-6 py-2.5 font-kufi text-sm text-gold-200 transition-colors hover:bg-gold-400/10"
          >
            عرض كل التصاميم
          </button>
        </div>
      ) : (
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((product, index) => (
            <ProductCard key={product.id} product={product} eager={index < 3} />
          ))}
        </div>
      )}

      {/* Size guide */}
      <div className="panel mt-16 overflow-hidden rounded-2xl">
        <div className="border-b border-gold-500/20 px-6 py-5">
          <h2 className="font-display text-xl text-gold-200">دليل المقاسات</h2>
          <p className="mt-1.5 text-sm text-mist">
            المقاس عندنا يعني طول العباية بالبوصة. إن كنت بين مقاسين، اختاري الأكبر
            ونقصّره لك مجانًا.
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-md text-start text-sm">
            <thead className="bg-wine-900/40 font-kufi text-xs text-gold-200">
              <tr>
                <th scope="col" className="px-6 py-3 text-start">المقاس</th>
                <th scope="col" className="px-6 py-3 text-start">الطول المناسب</th>
                <th scope="col" className="px-6 py-3 text-start">عرض الكتف</th>
              </tr>
            </thead>
            <tbody>
              {SIZE_GUIDE.map((row) => (
                <tr key={row.size} className="border-t border-gold-500/10">
                  <td className="px-6 py-3 font-kufi text-gold-100">{row.size}</td>
                  <td className="px-6 py-3 text-mist">{row.height}</td>
                  <td className="px-6 py-3 text-mist">{row.shoulder}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="border-t border-gold-500/20 px-6 py-4 text-xs text-mist">
          التوصيل مجاني للطلبات من {formatPrice(STORE.freeShippingFrom)} — وما دون ذلك
          بقيمة {formatPrice(35)}.
        </p>
      </div>
    </section>
  )
}
