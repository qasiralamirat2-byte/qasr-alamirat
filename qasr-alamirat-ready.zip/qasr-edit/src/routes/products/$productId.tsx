import { useState } from 'react'
import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { ArrowLeft, Check, Minus, Plus, Ruler, ShieldCheck, Truck } from 'lucide-react'
import { Ornament, WhatsAppIcon } from '@/components/Brand'
import { ProductCard } from '@/components/ProductCard'
import products, { SIZE_GUIDE, productById } from '@/data/products'
import { productOrderMessage, useCart } from '@/lib/cart'
import { img, imgSrcSet } from '@/lib/images'
import { STORE, formatPrice, whatsappLink } from '@/lib/store'

export const Route = createFileRoute('/products/$productId')({
  loader: ({ params }) => {
    const product = productById(params.productId)
    if (!product) throw notFound()
    return product
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.name} | ${STORE.name}` },
          { name: 'description', content: loaderData.tagline },
        ]
      : [],
  }),
  component: ProductPage,
})

function ProductPage() {
  const product = Route.useLoaderData()
  const cart = useCart()
  const [size, setSize] = useState(
    product.sizes[Math.floor(product.sizes.length / 2)],
  )
  const [color, setColor] = useState(product.colors[0].name)
  const [quantity, setQuantity] = useState(1)
  const [justAdded, setJustAdded] = useState(false)

  const related = products
    .filter((item) => item.id !== product.id && item.category === product.category)
    .concat(products.filter((item) => item.id !== product.id))
    .filter((item, index, list) => list.findIndex((p) => p.id === item.id) === index)
    .slice(0, 3)

  const handleAdd = () => {
    cart.add({ productId: product.id, size, color, quantity })
    setJustAdded(true)
    window.setTimeout(() => setJustAdded(false), 1800)
  }

  return (
    <>
      <nav className="mx-auto max-w-7xl px-4 pt-8 md:px-6" aria-label="مسار التنقل">
        <ol className="flex flex-wrap items-center gap-2 font-kufi text-xs text-mist">
          <li>
            <Link to="/" className="transition-colors hover:text-gold-200">الرئيسية</Link>
          </li>
          <li aria-hidden="true">/</li>
          <li>
            <Link to="/products" className="transition-colors hover:text-gold-200">المعرض</Link>
          </li>
          <li aria-hidden="true">/</li>
          <li className="text-gold-200">{product.name}</li>
        </ol>
      </nav>

      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-10 md:px-6 lg:grid-cols-[1fr_1fr] lg:gap-14">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <div className="arch overflow-hidden border border-gold-500/35 shadow-lift">
            <img
              src={img(product.image, 900)}
              srcSet={imgSrcSet(product.image, 900)}
              sizes="(max-width: 1024px) 100vw, 48vw"
              alt={`${product.name} — ${product.tagline}`}
              width={900}
              height={1200}
              className="aspect-3/4 w-full object-cover"
            />
          </div>
          <p className="mt-4 text-center font-kufi text-[0.7rem] text-mist">
            رقم القطعة {product.sku} · {product.fabric}
          </p>
        </div>

        <div>
          {product.badge && (
            <span className="inline-block rounded-full border border-gold-300/50 px-3 py-1 font-kufi text-[0.65rem] text-gold-200">
              {product.badge}
            </span>
          )}

          <h1 className="mt-4 font-display text-3xl md:text-5xl">
            <span className="gold-text">{product.name}</span>
          </h1>
          <p className="mt-3 text-lg text-sand/90">{product.tagline}</p>

          <div className="mt-6 flex items-baseline gap-3">
            <span className="font-kufi text-2xl text-gold-200">
              {formatPrice(product.price)}
            </span>
            {product.wasPrice && (
              <>
                <span className="text-base text-mist line-through">
                  {formatPrice(product.wasPrice)}
                </span>
                <span className="rounded-full bg-wine-700/60 px-2.5 py-1 font-kufi text-[0.65rem] text-gold-100">
                  وفّري {formatPrice(product.wasPrice - product.price)}
                </span>
              </>
            )}
          </div>

          <p className="mt-6 leading-loose text-mist">{product.description}</p>

          <Ornament className="my-8" />

          {/* Size */}
          <div>
            <div className="flex items-center justify-between">
              <h2 className="font-kufi text-sm text-sand">المقاس</h2>
              <span className="flex items-center gap-1.5 font-kufi text-[0.7rem] text-gold-200">
                <Ruler className="h-3.5 w-3.5" aria-hidden="true" />
                المقاس = طول العباية بالبوصة
              </span>
            </div>
            <div className="mt-3 flex flex-wrap gap-2.5">
              {product.sizes.map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setSize(option)}
                  aria-pressed={size === option}
                  className={`h-11 min-w-14 rounded-lg border px-3 font-kufi text-sm transition-colors ${
                    size === option
                      ? 'border-gold-300 bg-gold-400/15 text-gold-100'
                      : 'border-gold-500/25 text-mist hover:border-gold-400/60 hover:text-sand'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
            <p className="mt-2.5 text-xs text-mist">
              يناسب المقاس {size} الطول{' '}
              {SIZE_GUIDE.find((row) => row.size === size)?.height ?? '—'}
            </p>
          </div>

          {/* Color */}
          <div className="mt-8">
            <h2 className="font-kufi text-sm text-sand">
              اللون: <span className="text-gold-200">{color}</span>
            </h2>
            <div className="mt-3 flex flex-wrap gap-3">
              {product.colors.map((option) => (
                <button
                  key={option.name}
                  type="button"
                  onClick={() => setColor(option.name)}
                  aria-label={option.name}
                  aria-pressed={color === option.name}
                  title={option.name}
                  className={`h-11 w-11 rounded-full border transition-transform hover:scale-110 ${
                    color === option.name
                      ? 'border-gold-300 ring-2 ring-gold-400/40 ring-offset-2 ring-offset-ink'
                      : 'border-gold-500/30'
                  }`}
                  style={{ backgroundColor: option.hex }}
                />
              ))}
            </div>
          </div>

          {/* Quantity + actions */}
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 rounded-full border border-gold-500/30 px-2 py-1.5">
              <button
                type="button"
                onClick={() => setQuantity((value) => Math.max(1, value - 1))}
                aria-label="تقليل الكمية"
                className="rounded-full p-2 text-gold-200 transition-colors hover:bg-gold-400/10"
              >
                <Minus className="h-4 w-4" aria-hidden="true" />
              </button>
              <span className="min-w-8 text-center font-kufi text-sand">
                {quantity.toLocaleString('ar-SA')}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((value) => Math.min(20, value + 1))}
                aria-label="زيادة الكمية"
                className="rounded-full p-2 text-gold-200 transition-colors hover:bg-gold-400/10"
              >
                <Plus className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
            <span className="font-kufi text-sm text-mist">
              الإجمالي: {formatPrice(product.price * quantity)}
            </span>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <button
              type="button"
              onClick={handleAdd}
              className="flex items-center justify-center gap-2 rounded-full border border-gold-400/50 bg-gold-400/10 py-4 font-kufi text-sm text-gold-100 transition-colors hover:bg-gold-400/20"
            >
              {justAdded ? (
                <>
                  <Check className="h-4 w-4" aria-hidden="true" />
                  أُضيفت إلى السلة
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4" aria-hidden="true" />
                  أضيفي إلى السلة
                </>
              )}
            </button>
            <a
              href={whatsappLink(productOrderMessage(product, size, color))}
              target="_blank"
              rel="noreferrer noopener"
              className="flex items-center justify-center gap-2 rounded-full bg-[#1f6b4f] py-4 font-kufi text-sm text-white transition-colors hover:bg-[#248059]"
            >
              <WhatsAppIcon className="h-5 w-5" />
              اطلبيها عبر واتساب
            </a>
          </div>

          {/* Details */}
          <dl className="mt-10 divide-y divide-gold-500/15 border-y border-gold-500/15 text-sm">
            {[
              { label: 'القماش', value: product.fabric },
              { label: 'العناية', value: product.care },
              { label: 'التصنيف', value: product.category },
              {
                label: 'التوصيل',
                value: `٢ – ٤ أيام عمل · مجاني من ${formatPrice(STORE.freeShippingFrom)}`,
              },
            ].map((row) => (
              <div key={row.label} className="flex gap-6 py-3.5">
                <dt className="w-24 shrink-0 font-kufi text-xs text-gold-200">
                  {row.label}
                </dt>
                <dd className="text-mist">{row.value}</dd>
              </div>
            ))}
          </dl>

          <ul className="mt-6 flex flex-wrap gap-5 text-xs text-mist">
            <li className="flex items-center gap-1.5">
              <Truck className="h-4 w-4 text-gold-400" aria-hidden="true" />
              شحن مُتتبَّع
            </li>
            <li className="flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-gold-400" aria-hidden="true" />
              استبدال خلال ٧ أيام
            </li>
            <li className="flex items-center gap-1.5">
              <Ruler className="h-4 w-4 text-gold-400" aria-hidden="true" />
              تقصير مجاني
            </li>
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-8 md:px-6">
        <Link
          to="/products"
          className="inline-flex items-center gap-2 font-kufi text-sm text-gold-200 transition-colors hover:text-gold-100"
        >
          <ArrowLeft className="h-4 w-4 rotate-180" aria-hidden="true" />
          رجوع إلى المعرض
        </Link>

        <h2 className="mt-10 text-center font-display text-2xl md:text-3xl">
          <span className="gold-text">قد يناسبك أيضًا</span>
        </h2>
        <Ornament className="mt-4" />

        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {related.map((item) => (
            <ProductCard key={item.id} product={item} />
          ))}
        </div>
      </section>
    </>
  )
}
