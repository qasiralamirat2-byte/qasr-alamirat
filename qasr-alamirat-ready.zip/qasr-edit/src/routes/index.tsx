import { Link, createFileRoute } from '@tanstack/react-router'
import { MapPin, Ruler, Scissors, Sparkles, Truck } from 'lucide-react'
import { Crest, Ornament, WhatsAppIcon } from '@/components/Brand'
import { ProductCard } from '@/components/ProductCard'
import products from '@/data/products'
import { img, imgSrcSet } from '@/lib/images'
import { STORE, WHATSAPP_GREETING, formatPrice, whatsappLink } from '@/lib/store'

export const Route = createFileRoute('/')({
  component: HomePage,
})

const PROMISES = [
  { icon: Scissors, title: 'خياطة على مقاسك', text: 'تعديل الطول والأكمام مجانًا مع كل عباية' },
  { icon: Sparkles, title: 'أقمشة مختارة', text: 'مخمل إيطالي، كريب ياباني، ونِدا كوري' },
  { icon: Truck, title: 'توصيل سريع', text: `مجاني من ${formatPrice(STORE.freeShippingFrom)} لكل مناطق المملكة` },
  { icon: Ruler, title: 'استبدال ميسّر', text: 'خلال ٧ أيام إن لم يناسبك المقاس' },
]

const VOICES = [
  {
    name: 'لمى الحربي',
    city: 'الرياض',
    text: 'طلبت عباية ليلة الأمير لعقد أختي. التطريز أدق مما ظهر في الصور، والطول جاء مضبوطًا بعد ما أرسلت قياسي على الواتساب.',
  },
  {
    name: 'نوف بن عمر',
    city: 'جدة',
    text: 'أشتري منهن منذ سنتين. عباية نسيم الحرير عندي منها أربع قطع، تُغسل في البيت ولا تفقد انسدالها.',
  },
  {
    name: 'دلال القحطاني',
    city: 'الخبر',
    text: 'خدمة الواتساب مريحة جدًا، أرسلت مقاسي ووصلتني العباية خلال ثلاثة أيام مع كيس قماشي أنيق.',
  },
]

function HomePage() {
  const featured = products.filter((product) => product.featured)

  return (
    <>
      {/* ── Hero ───────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 md:px-6 lg:grid-cols-[1.05fr_1fr] lg:py-20">
          <div className="rise">
            <span className="inline-flex items-center gap-2 rounded-full border border-gold-500/35 px-4 py-1.5 font-kufi text-[0.7rem] text-gold-200">
              <Crest className="h-4 w-4" />
              دار خياطة سعودية · تأسست ٢٠١٦
            </span>

            <h1 className="mt-6 font-display text-4xl leading-[1.25] md:text-6xl">
              <span className="gold-text">{STORE.name}</span>
              <span className="mt-3 block text-2xl text-sand md:text-3xl">
                {STORE.tagline}
              </span>
            </h1>

            <p className="mt-6 max-w-xl text-base leading-loose text-mist md:text-lg">
              ثمانية تصاميم تُخاط في ورشتنا في {STORE.city}: مخمل مطرّز بخيوط الذهب،
              كريب سادة للأيام العادية، وبليسيه خفيف للسهرات. اختاري المقاس واللون،
              وأكملي الطلب عبر واتساب في دقيقة واحدة.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <Link
                to="/products"
                className="rounded-full bg-gradient-to-l from-gold-600 via-gold-400 to-gold-300 px-8 py-3.5 font-kufi text-sm font-bold text-wine-950 shadow-lift transition-transform hover:scale-[1.02]"
              >
                تصفّحي المعرض
              </Link>
              <a
                href={whatsappLink(WHATSAPP_GREETING)}
                target="_blank"
                rel="noreferrer noopener"
                className="flex items-center gap-2 rounded-full border border-gold-400/50 px-7 py-3.5 font-kufi text-sm text-gold-100 transition-colors hover:bg-gold-400/10"
              >
                <WhatsAppIcon className="h-4 w-4" />
                استفسري على واتساب
              </a>
            </div>

            <dl className="mt-11 grid max-w-lg grid-cols-3 gap-4 border-t border-gold-500/20 pt-6">
              {[
                { value: '٨', label: 'تصاميم متوفرة' },
                { value: '٥', label: 'مقاسات لكل تصميم' },
                { value: '٣٬٤٠٠+', label: 'عباية سلّمناها' },
              ].map((stat) => (
                <div key={stat.label}>
                  <dt className="font-display text-2xl text-gold-200 md:text-3xl">
                    {stat.value}
                  </dt>
                  <dd className="mt-1 font-kufi text-[0.7rem] text-mist">{stat.label}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative rise">
            <div className="arch overflow-hidden border border-gold-500/35 shadow-lift">
              <img
                src={img('hero.png', 900)}
                srcSet={imgSrcSet('hero.png', 900)}
                sizes="(max-width: 1024px) 100vw, 50vw"
                alt="ثلاث عبايات فاخرة معروضة في صالة قصر بأقواس مزخرفة وفوانيس نحاسية"
                width={900}
                height={502}
                className="aspect-4/5 w-full object-cover object-center lg:aspect-3/4"
              />
            </div>

            <div className="panel absolute -bottom-6 start-4 max-w-[15rem] rounded-xl p-4 shadow-lift md:start-8">
              <p className="font-display text-base text-gold-200">صالة العرض</p>
              <p className="mt-1.5 flex items-start gap-1.5 text-xs leading-relaxed text-mist">
                <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                حي الياسمين، {STORE.city} — بموعد مسبق
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Promises ───────────────────────────────────────────────────── */}
      <section className="border-y border-gold-500/20 bg-wine-950/40">
        <ul className="mx-auto grid max-w-7xl gap-px px-4 py-2 sm:grid-cols-2 md:px-6 lg:grid-cols-4">
          {PROMISES.map(({ icon: Icon, title, text }) => (
            <li
              key={title}
              className="flex items-start gap-3 px-2 py-6 lg:border-gold-500/15 lg:[&:not(:last-child)]:border-e"
            >
              <Icon className="mt-0.5 h-5 w-5 shrink-0 text-gold-400" aria-hidden="true" />
              <div>
                <p className="font-kufi text-sm text-sand">{title}</p>
                <p className="mt-1 text-xs leading-relaxed text-mist">{text}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {/* ── Featured collection ────────────────────────────────────────── */}
      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
        <div className="text-center">
          <p className="font-kufi text-xs text-gold-400">مختارات القصر</p>
          <h2 className="mt-3 font-display text-3xl md:text-4xl">
            <span className="gold-text">القطع الأكثر طلبًا هذا الموسم</span>
          </h2>
          <Ornament className="mt-5" />
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((product, index) => (
            <ProductCard key={product.id} product={product} eager={index < 2} />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link
            to="/products"
            className="inline-block rounded-full border border-gold-400/50 px-8 py-3.5 font-kufi text-sm text-gold-200 transition-colors hover:bg-gold-400/10"
          >
            شاهدي كل العبايات الثماني
          </Link>
        </div>
      </section>

      {/* ── Atelier story ──────────────────────────────────────────────── */}
      <section className="mx-auto max-w-7xl px-4 pb-16 md:px-6 md:pb-24">
        <div className="grid items-center gap-10 lg:grid-cols-[1fr_1.1fr]">
          <div className="arch overflow-hidden border border-gold-500/30 shadow-lift">
            <img
              src={img('abaya-sundus.png', 760)}
              srcSet={imgSrcSet('abaya-sundus.png', 760)}
              sizes="(max-width: 1024px) 100vw, 45vw"
              alt="عباية سُندس الكيمونو بتطريز نباتي ذهبي على قماش أسود"
              width={760}
              height={1013}
              loading="lazy"
              className="aspect-4/5 w-full object-cover"
            />
          </div>

          <div>
            <p className="font-kufi text-xs text-gold-400">عن القصر</p>
            <h2 className="mt-3 font-display text-3xl leading-snug md:text-4xl">
              كل عباية تمرّ على يد ثلاث خيّاطات قبل أن تصلك
            </h2>
            <div className="mt-6 space-y-4 leading-loose text-mist">
              <p>
                بدأت الورشة عام ٢٠١٦ بماكينتين وطلبات من الأهل والصديقات. اليوم يعمل
                في {STORE.name} فريق من إحدى عشرة خيّاطة ومطرّزة، ولا يزال قياس كل
                عباية يُراجع يدويًا قبل تغليفها.
              </p>
              <p>
                نشتري المخمل من ميلانو والكريب من أوساكا، ونطرّز خيوط الزري في الورشة
                نفسها. لذلك نطبع رقم القطعة داخل كل عباية؛ إن احتجت ترميمًا بعد سنة،
                نعرف تمامًا من خاطها وبأي خيط.
              </p>
            </div>

            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {[
                'قياس عن بُعد عبر واتساب في ٣ خطوات',
                'تطريز الأسماء والحروف الأولى حسب الطلب',
                'تغليف في كيس قماشي قابل للاستخدام',
                'خدمة ترميم وتنظيف للعبايات القديمة',
              ].map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-2 text-sm leading-relaxed text-sand/90"
                >
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rotate-45 bg-gold-400" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* ── Voices ─────────────────────────────────────────────────────── */}
      <section className="border-y border-gold-500/20 bg-wine-950/40 py-16 md:py-20">
        <div className="mx-auto max-w-7xl px-4 md:px-6">
          <h2 className="text-center font-display text-2xl md:text-3xl">
            <span className="gold-text">قالت عنّا</span>
          </h2>
          <Ornament className="mt-5" />

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {VOICES.map((voice) => (
              <figure key={voice.name} className="panel rounded-2xl p-6">
                <svg viewBox="0 0 24 24" className="h-6 w-6 text-gold-400/70" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M9 5H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v1a3 3 0 0 1-3 3v2a5 5 0 0 0 5-5V5Zm11 0h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v1a3 3 0 0 1-3 3v2a5 5 0 0 0 5-5V5Z"
                  />
                </svg>
                <blockquote className="mt-4 text-sm leading-loose text-sand/90">
                  {voice.text}
                </blockquote>
                <figcaption className="mt-5 border-t border-gold-500/20 pt-4 font-kufi text-xs text-gold-200">
                  {voice.name}
                  <span className="text-mist"> — {voice.city}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* ── Contact band ───────────────────────────────────────────────── */}
      <section id="contact" className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
        <div className="panel relative overflow-hidden rounded-3xl px-6 py-12 text-center md:px-16">
          <Crest className="mx-auto h-12 w-12" />
          <h2 className="mt-5 font-display text-2xl md:text-4xl">
            <span className="gold-text">اطلبي عبايتك عبر واتساب</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl leading-loose text-mist">
            أرسلي لنا التصميم الذي أعجبك مع طولك ومقاس كتفك، ونؤكد لك التوفر والسعر
            ووقت التسليم فورًا. فريق الخدمة يجيب من {STORE.hours.split('·')[0].trim()}.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <a
              href={whatsappLink(WHATSAPP_GREETING)}
              target="_blank"
              rel="noreferrer noopener"
              className="flex items-center gap-2 rounded-full bg-[#1f6b4f] px-8 py-3.5 font-kufi text-sm text-white transition-colors hover:bg-[#248059]"
            >
              <WhatsAppIcon className="h-5 w-5" />
              محادثة واتساب مباشرة
            </a>
            <Link
              to="/contact"
              className="rounded-full border border-gold-400/50 px-8 py-3.5 font-kufi text-sm text-gold-200 transition-colors hover:bg-gold-400/10"
            >
              بيانات التواصل وصالة العرض
            </Link>
          </div>

          <p className="mt-6 font-kufi text-sm text-gold-200" dir="ltr">
            {STORE.whatsappDisplay}
          </p>
        </div>
      </section>
    </>
  )
}
