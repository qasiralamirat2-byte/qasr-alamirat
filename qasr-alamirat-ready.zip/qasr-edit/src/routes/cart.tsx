import { Link, createFileRoute } from '@tanstack/react-router'
import { Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react'
import { Ornament, WhatsAppIcon } from '@/components/Brand'
import { lineKey, useCart } from '@/lib/cart'
import { img, imgSrcSet } from '@/lib/images'
import { STORE, formatPrice } from '@/lib/store'

export const Route = createFileRoute('/cart')({
  head: () => ({ meta: [{ title: `سلة المشتريات | ${STORE.name}` }] }),
  component: CartPage,
})

function CartPage() {
  const cart = useCart()

  return (
    <section className="mx-auto max-w-6xl px-4 py-12 md:px-6 md:py-16">
      <header className="text-center">
        <p className="font-kufi text-xs text-gold-400">الخطوة الأخيرة</p>
        <h1 className="mt-3 font-display text-3xl md:text-5xl">
          <span className="gold-text">سلة المشتريات</span>
        </h1>
        <Ornament className="mt-5" />
      </header>

      {!cart.ready ? (
        /* Skeleton matching the row layout while the saved cart is restored */
        <ul className="mt-12 space-y-4" aria-hidden="true">
          {[0, 1].map((row) => (
            <li key={row} className="panel flex gap-4 rounded-2xl p-4">
              <div className="h-40 w-28 animate-pulse rounded-lg bg-wine-800/50" />
              <div className="flex-1 space-y-3 py-2">
                <div className="h-5 w-40 animate-pulse rounded bg-wine-800/50" />
                <div className="h-4 w-24 animate-pulse rounded bg-wine-800/40" />
                <div className="h-9 w-32 animate-pulse rounded-full bg-wine-800/40" />
              </div>
            </li>
          ))}
        </ul>
      ) : cart.entries.length === 0 ? (
        <div className="panel mx-auto mt-12 max-w-xl rounded-3xl px-8 py-16 text-center">
          <div className="arch mx-auto flex h-32 w-24 items-center justify-center border border-gold-500/30 bg-wine-900/40">
            <ShoppingBag className="h-8 w-8 text-gold-400/70" aria-hidden="true" />
          </div>
          <h2 className="mt-7 font-display text-2xl text-sand">السلة فارغة</h2>
          <p className="mx-auto mt-3 max-w-sm leading-relaxed text-mist">
            لم تُضيفي أي عباية بعد. تفضّلي بزيارة المعرض واختاري تصميمك، ثم حدّدي
            المقاس واللون قبل الإضافة.
          </p>
          <Link
            to="/products"
            className="mt-8 inline-block rounded-full bg-gradient-to-l from-gold-600 via-gold-400 to-gold-300 px-8 py-3.5 font-kufi text-sm font-bold text-wine-950"
          >
            تصفّحي المعرض
          </Link>
        </div>
      ) : (
        <div className="mt-12 grid gap-8 lg:grid-cols-[1.6fr_1fr] lg:items-start">
          <ul className="space-y-4">
            {cart.entries.map((entry) => (
              <li key={lineKey(entry)} className="panel flex flex-col gap-4 rounded-2xl p-4 sm:flex-row">
                <Link
                  to="/products/$productId"
                  params={{ productId: entry.product.id }}
                  className="shrink-0"
                >
                  <img
                    src={img(entry.product.image, 220, 293)}
                    srcSet={imgSrcSet(entry.product.image, 220, 293)}
                    alt={entry.product.name}
                    width={220}
                    height={293}
                    loading="lazy"
                    className="h-52 w-full rounded-xl object-cover sm:h-52 sm:w-40"
                  />
                </Link>

                <div className="flex flex-1 flex-col">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <Link
                        to="/products/$productId"
                        params={{ productId: entry.product.id }}
                        className="font-display text-xl text-sand transition-colors hover:text-gold-200"
                      >
                        {entry.product.name}
                      </Link>
                      <p className="mt-1 text-sm text-mist">{entry.product.tagline}</p>
                      <p className="mt-2 font-kufi text-xs text-mist">
                        المقاس {entry.size} · {entry.color} · {entry.product.sku}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => cart.remove(entry)}
                      aria-label={`إزالة ${entry.product.name}`}
                      className="rounded-full p-2 text-mist transition-colors hover:bg-wine-700/40 hover:text-gold-200"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </div>

                  <div className="mt-5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 rounded-full border border-gold-500/30 px-1.5 py-1">
                      <button
                        type="button"
                        onClick={() => cart.setQuantity(entry, entry.quantity - 1)}
                        aria-label="تقليل الكمية"
                        className="rounded-full p-2 text-gold-200 transition-colors hover:bg-gold-400/10"
                      >
                        <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <span className="min-w-7 text-center font-kufi text-sm text-sand">
                        {entry.quantity.toLocaleString('ar-SA')}
                      </span>
                      <button
                        type="button"
                        onClick={() => cart.setQuantity(entry, entry.quantity + 1)}
                        aria-label="زيادة الكمية"
                        className="rounded-full p-2 text-gold-200 transition-colors hover:bg-gold-400/10"
                      >
                        <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                    <span className="font-kufi text-base text-gold-200">
                      {formatPrice(entry.product.price * entry.quantity)}
                    </span>
                  </div>
                </div>
              </li>
            ))}

            <li className="flex items-center justify-between pt-2">
              <Link
                to="/products"
                className="font-kufi text-sm text-gold-200 underline decoration-gold-500/40 underline-offset-4"
              >
                إضافة عباية أخرى
              </Link>
              <button
                type="button"
                onClick={cart.clear}
                className="font-kufi text-sm text-mist transition-colors hover:text-gold-200"
              >
                تفريغ السلة
              </button>
            </li>
          </ul>

          <aside className="panel rounded-2xl p-6 lg:sticky lg:top-32">
            <h2 className="font-display text-xl text-gold-200">ملخص الطلب</h2>

            <dl className="mt-5 space-y-2.5 text-sm">
              <div className="flex justify-between">
                <dt className="text-mist">عدد القطع</dt>
                <dd className="text-sand">{cart.count.toLocaleString('ar-SA')}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-mist">الإجمالي الفرعي</dt>
                <dd className="text-sand">{formatPrice(cart.subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-mist">التوصيل</dt>
                <dd className="text-sand">
                  {cart.shipping === 0 ? 'مجاني' : formatPrice(cart.shipping)}
                </dd>
              </div>
              <Ornament className="py-2" />
              <div className="flex justify-between font-kufi text-lg">
                <dt className="text-gold-200">الإجمالي</dt>
                <dd className="text-gold-200">{formatPrice(cart.total)}</dd>
              </div>
            </dl>

            {cart.shipping > 0 && (
              <p className="mt-4 rounded-lg border border-gold-500/20 bg-wine-900/30 px-3 py-2.5 text-xs leading-relaxed text-gold-200">
                أضيفي بقيمة {formatPrice(STORE.freeShippingFrom - cart.subtotal)} ليصبح
                التوصيل مجانيًا.
              </p>
            )}

            <a
              href={cart.orderLink()}
              target="_blank"
              rel="noreferrer noopener"
              className="mt-6 flex items-center justify-center gap-2 rounded-full bg-[#1f6b4f] py-4 font-kufi text-sm text-white transition-colors hover:bg-[#248059]"
            >
              <WhatsAppIcon className="h-5 w-5" />
              إتمام الطلب عبر واتساب
            </a>

            <ol className="mt-6 space-y-2.5 text-xs leading-relaxed text-mist">
              {[
                'نفتح لك محادثة واتساب فيها تفاصيل السلة كاملة.',
                'نؤكد التوفر والمقاس ونرسل عنوان الدفع أو الدفع عند التسليم.',
                'تُشحن العباية خلال ٢ – ٤ أيام عمل مع رقم تتبع.',
              ].map((step, index) => (
                <li key={step} className="flex gap-2.5">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-gold-500/40 font-kufi text-[0.65rem] text-gold-200">
                    {(index + 1).toLocaleString('ar-SA')}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </aside>
        </div>
      )}
    </section>
  )
}
