import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'
import type { Product } from '@/data/products'
import { productById } from '@/data/products'
import { STORE, formatPrice, whatsappLink } from '@/lib/store'

const STORAGE_KEY = 'qasr-al-amirat.cart.v1'

export type CartLine = {
  productId: string
  size: string
  color: string
  quantity: number
}

export type CartEntry = CartLine & { product: Product }

type CartValue = {
  lines: Array<CartLine>
  entries: Array<CartEntry>
  count: number
  subtotal: number
  shipping: number
  total: number
  /** false until the browser has restored the saved cart (keeps SSR markup stable) */
  ready: boolean
  drawerOpen: boolean
  lastAdded: string | null
  add: (line: CartLine) => void
  setQuantity: (line: CartLine, quantity: number) => void
  remove: (line: CartLine) => void
  clear: () => void
  openDrawer: () => void
  closeDrawer: () => void
  orderMessage: () => string
  orderLink: () => string
}

const CartContext = createContext<CartValue | null>(null)

const sameLine = (a: CartLine, b: CartLine) =>
  a.productId === b.productId && a.size === b.size && a.color === b.color

export const lineKey = (line: CartLine) =>
  `${line.productId}__${line.size}__${line.color}`

function readStorage(): Array<CartLine> {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    // Drop anything that no longer matches the catalogue.
    return parsed.filter(
      (line): line is CartLine =>
        typeof line?.productId === 'string' &&
        typeof line?.size === 'string' &&
        typeof line?.color === 'string' &&
        Number.isFinite(line?.quantity) &&
        line.quantity > 0 &&
        Boolean(productById(line.productId)),
    )
  } catch {
    return []
  }
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<Array<CartLine>>([])
  const [ready, setReady] = useState(false)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [lastAdded, setLastAdded] = useState<string | null>(null)

  useEffect(() => {
    setLines(readStorage())
    setReady(true)
  }, [])

  useEffect(() => {
    if (!ready) return
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines))
    } catch {
      /* private browsing — the cart simply stays in memory */
    }
  }, [lines, ready])

  const add = useCallback((line: CartLine) => {
    setLines((current) => {
      const existing = current.find((item) => sameLine(item, line))
      if (existing) {
        return current.map((item) =>
          sameLine(item, line)
            ? { ...item, quantity: Math.min(item.quantity + line.quantity, 20) }
            : item,
        )
      }
      return [...current, line]
    })
    setLastAdded(lineKey(line))
    setDrawerOpen(true)
  }, [])

  const setQuantity = useCallback((line: CartLine, quantity: number) => {
    setLines((current) =>
      quantity <= 0
        ? current.filter((item) => !sameLine(item, line))
        : current.map((item) =>
            sameLine(item, line)
              ? { ...item, quantity: Math.min(quantity, 20) }
              : item,
          ),
    )
  }, [])

  const remove = useCallback((line: CartLine) => {
    setLines((current) => current.filter((item) => !sameLine(item, line)))
  }, [])

  const value = useMemo<CartValue>(() => {
    const entries = lines.flatMap((line) => {
      const product = productById(line.productId)
      return product ? [{ ...line, product }] : []
    })
    const subtotal = entries.reduce(
      (sum, entry) => sum + entry.product.price * entry.quantity,
      0,
    )
    const shipping = subtotal === 0 || subtotal >= STORE.freeShippingFrom ? 0 : 35
    const count = entries.reduce((sum, entry) => sum + entry.quantity, 0)

    const orderMessage = () => {
      const header = `السلام عليكم، أرغب بتأكيد هذا الطلب من ${STORE.name}:`
      const body = entries
        .map(
          (entry, index) =>
            `${index + 1}) ${entry.product.name} — ${entry.product.sku}\n` +
            `    المقاس: ${entry.size} · اللون: ${entry.color} · الكمية: ${entry.quantity}\n` +
            `    السعر: ${formatPrice(entry.product.price * entry.quantity)}`,
        )
        .join('\n')
      const totals =
        `الإجمالي الفرعي: ${formatPrice(subtotal)}\n` +
        `التوصيل: ${shipping === 0 ? 'مجاني' : formatPrice(shipping)}\n` +
        `الإجمالي: ${formatPrice(subtotal + shipping)}`
      return `${header}\n\n${body}\n\n${totals}`
    }

    return {
      lines,
      entries,
      count,
      subtotal,
      shipping,
      total: subtotal + shipping,
      ready,
      drawerOpen,
      lastAdded,
      add,
      setQuantity,
      remove,
      clear: () => setLines([]),
      openDrawer: () => setDrawerOpen(true),
      closeDrawer: () => setDrawerOpen(false),
      orderMessage,
      orderLink: () => whatsappLink(orderMessage()),
    }
  }, [lines, ready, drawerOpen, lastAdded, add, setQuantity, remove])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) throw new Error('useCart must be used inside <CartProvider>')
  return context
}

/** WhatsApp message for ordering a single abaya straight from its card. */
export function productOrderMessage(
  product: Product,
  size: string,
  color: string,
) {
  return (
    `السلام عليكم، أرغب بطلب هذه العباية من ${STORE.name}:\n\n` +
    `${product.name} — ${product.sku}\n` +
    `المقاس: ${size}\n` +
    `اللون: ${color}\n` +
    `السعر: ${formatPrice(product.price)}`
  )
}
