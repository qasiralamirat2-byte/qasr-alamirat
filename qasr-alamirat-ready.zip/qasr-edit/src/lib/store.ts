/**
 * Single source of truth for everything about the boutique that an owner may
 * want to change without touching components.
 *
 * ▸ `whatsapp` MUST be the shop's real number in full international format,
 *   digits only (country code first, no "+", no spaces). Every order button and
 *   contact link on the site is built from this one value.
 */
export const STORE = {
  name: 'قصر الأميرات',
  nameLatin: 'Qasr Al Amirat',
  tagline: 'عبايات فاخرة تُخاط لمن تعرف قدرها',
  whatsapp: '966500000000',
  whatsappDisplay: '+966 50 000 0000',
  email: 'orders@qasr-alamirat.com',
  city: 'الرياض',
  address: 'حي الياسمين، طريق أنس بن مالك، الرياض، المملكة العربية السعودية',
  hours: 'السبت – الخميس: ١١ صباحًا – ١٠ مساءً · الجمعة: ٤ – ١٠ مساءً',
  instagram: 'qasr.alamirat',
  currency: 'ر.س',
  freeShippingFrom: 600,
} as const

/** Arabic-Indic grouping for prices, e.g. ١٫٢٩٠ ر.س */
export function formatPrice(value: number) {
  return `${value.toLocaleString('ar-SA', { maximumFractionDigits: 0 })} ${STORE.currency}`
}

export function whatsappLink(message: string) {
  return `https://wa.me/${STORE.whatsapp}?text=${encodeURIComponent(message)}`
}

export const WHATSAPP_GREETING = `السلام عليكم، أرغب بالاستفسار عن عبايات ${STORE.name}.`
