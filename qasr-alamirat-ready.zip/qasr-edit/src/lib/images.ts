/**
 * All product photography is served through the Netlify Image CDN so the
 * full-resolution originals in /public/img never reach a visitor's browser.
 */
export function img(file: string, width: number, height?: number) {
  const params = new URLSearchParams({
    url: `/img/${file}`,
    w: String(width),
    fm: 'webp',
    q: '78',
  })
  if (height) {
    params.set('h', String(height))
    params.set('fit', 'cover')
  }
  return `/.netlify/images?${params.toString()}`
}

/** 1x/2x srcSet for crisp rendering on phones and retina screens. */
export function imgSrcSet(file: string, width: number, height?: number) {
  return `${img(file, width, height)} 1x, ${img(file, width * 2, height ? height * 2 : undefined)} 2x`
}
