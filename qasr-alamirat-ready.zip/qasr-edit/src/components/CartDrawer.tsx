import { useEffect } from 'react'
import { Link } from '@tanstack/react-router'
import { Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react'
import { Ornament, WhatsAppIcon } from '@/components/Brand'
import { lineKey, useCart } from '@/lib/cart'
import { imgSrcSet, img } from '@/lib/images'
import { STORE, formatPrice } from '@/lib/store'

export function CartDrawer() {
  const cart = useCart()

  useEffect(() => {
    if (!cart.drawerOpen) return
    const previous = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') cart.closeDrawer()
    }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = previous
      window.removeEventListener('keydown', onKey)
    }
  }, [cart.drawerOpen, cart])

  if (!cart.drawerOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex" role="dialog" aria-modal="true" aria-label="سلة المشتريات">
      <button
        type="button"
        aria-label="إغلاق السلة"
        onClick={cart.closeDrawer}
        className="absolute inset-0 animate-[veil_.3s_ease-out] cursor-default bg-ink/80 backdrop-blur-sm"
      />

      <aside className="relative ms-auto flex h-full w-full max-w-md animate-[drawer-in_.4s_var(--ease-silk)] flex-col border-s border-gold-500/30 bg-night/95 shadow-lift">
        <div className="flex items-center justify-between border-b border-gold-500/20 px-5 py-4">
          <h2 className="flex items-center gap-2 font-display text-xl text-gold-200">
            <ShoppingBag className="h-5 w-5" aria-hidden="true" />
            سلة المشتريات
            {cart.count > 0 && (
              <span className="font-body text-sm text-mist">
                ({cart.count.toLocaleString('ar-SA')})
              </span>
            )}
          </h2>
          <button
            type="button"
            onClick={cart.closeDrawer}
            aria-label="إغلاق"
            className="rounded-full border border-gold-400/30 p-2 text-gold-200 transition-colors hover:bg-gold-400/10"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {cart.entries.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
            <div className="arch flex h-28 w-20 items-center justify-center border border-gold-500/30 bg-wine-900/40">
              <ShoppingBag className="h-7 w-7 text-gold-400/70" aria-hidden="true" />
            </div>
            <p className="font-display text-lg text-sand">سلتك فارغة حتى الآن</p>
            <p className="text-sm leading-relaxed text-mist">
              اختاري عبايتك من المعرض، وحدّدي المقاس واللون، وستجدينها هنا.
            </p>
            <Link
              to="/products"
              onClick={cart.closeDrawer}
              className="rounded-full border border-gold-400/50 px-6 py-2.5 font-kufi text-sm text-gold-200 transition-colors hover:bg-gold-400/10"
            >
              تصفّحي المعرض
            </Link>
          </div>
        ) : (
          <>
            <ul className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
              {cart.entries.map((entry) => {
                const key = lineKey(entry)
                return (
                  <li
                    key={key}
                    className={`panel flex gap-3 rounded-xl p-3 transition-shadow ${
                      cart.lastAdded === key ? 'ring-1 ring-gold-400/60' : ''
                    }`}
                  >
                    <Link
                      to="/products/$productId"
                      params={{ productId: entry.product.id }}
                      onClick={cart.closeDrawer}
                      className="shrink-0"
                    >
                      <img
                        src={img(entry.product.image, 96, 128)}
                        srcSet={imgSrcSet(entry.product.image, 96, 128)}
                        alt={entry.product.name}
                        width={96}
                        height={128}
                        className="h-32 w-24 rounded-lg object-cover"
                        loading="lazy"
                      />
                    </Link>

                    <div className="flex min-w-0 flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="truncate font-display text-base text-sand">
                          {entry.product.name}
                        </h3>
                        <button
                          type="button"
                          onClick={() => cart.remove(entry)}
                          aria-label={`إزالة ${entry.product.name}`}
                          className="shrink-0 rounded-full p-1.5 text-mist transition-colors hover:bg-wine-700/40 hover:text-gold-200"
                        >
                          <Trash2 className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>

                      <p className="mt-1 font-kufi text-xs text-mist">
                        المقاس {entry.size} · {entry.color}
                      </p>

                      <div className="mt-auto flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1 rounded-full border border-gold-500/30">
                          <button
                            type="button"
                            onClick={() => cart.setQuantity(entry, entry.quantity - 1)}
                            aria-label="تقليل الكمية"
                            className="rounded-full p-1.5 text-gold-200 transition-colors hover:bg-gold-400/10"
                          >
                            <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <span className="min-w-6 text-center text-sm text-sand">
                            {entry.quantity.toLocaleString('ar-SA')}
                          </span>
                          <button
                            type="button"
                            onClick={() => cart.setQuantity(entry, entry.quantity + 1)}
                            aria-label="زيادة الكمية"
                            className="rounded-full p-1.5 text-gold-200 transition-colors hover:bg-gold-400/10"
                          >
                            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                        </div>
                        <span className="font-kufi text-sm text-gold-200">
                          {formatPrice(entry.product.price * entry.quantity)}
                        </span>
                      </div>
                    </div>
                  </li>
                )
              })}
            </ul>

            <div className="border-t border-gold-500/20 px-5 py-4">
              <dl className="space-y-1.5 text-sm">
                <div className="flex justify-between text-mist">
                  <dt>الإجمالي الفرعي</dt>
                  <dd className="text-sand">{formatPrice(cart.subtotal)}</dd>
                </div>
                <div className="flex justify-between text-mist">
                  <dt>التوصيل</dt>
                  <dd className="text-sand">
                    {cart.shipping === 0 ? 'مجاني' : formatPrice(cart.shipping)}
                  </dd>
                </div>
                <Ornament className="py-1.5" />
                <div className="flex justify-between font-kufi text-base">
                  <dt className="text-gold-200">الإجمالي</dt>
                  <dd className="text-gold-200">{formatPrice(cart.total)}</dd>
                </div>
              </dl>

              <a
                href={cart.orderLink()}
                target="_blank"
                rel="noreferrer noopener"
                className="mt-4 flex items-center justify-center gap-2 rounded-full bg-[#1f6b4f] py-3.5 font-kufi text-sm text-white transition-transform hover:bg-[#248059] active:scale-[0.99]"
              >
                <WhatsAppIcon className="h-5 w-5" />
                إتمام الطلب عبر واتساب
              </a>

              <div className="mt-3 flex items-center justify-between">
                <Link
                  to="/cart"
                  onClick={cart.closeDrawer}
                  className="font-kufi text-xs text-gold-200 underline decoration-gold-500/40 underline-offset-4"
                >
                  عرض السلة كاملة
                </Link>
                <button
                  type="button"
                  onClick={cart.clear}
                  className="font-kufi text-xs text-mist transition-colors hover:text-gold-200"
                >
                  تفريغ السلة
                </button>
              </div>

              <p className="mt-3 text-center text-[0.68rem] leading-relaxed text-mist">
                يتم تأكيد الطلب والدفع عبر واتساب مع فريق {STORE.name}
              </p>
            </div>
          </>
        )}
      </aside>
    </div>
  )
}
