import { Link } from '@tanstack/react-router'
import { Clock, Instagram, Mail, MapPin } from 'lucide-react'
import { Logo, Ornament, WhatsAppIcon } from '@/components/Brand'
import { STORE, WHATSAPP_GREETING, whatsappLink } from '@/lib/store'

export function Footer() {
  return (
    <footer className="mt-24 border-t border-gold-500/25 bg-wine-950/50">
      <div className="mx-auto max-w-7xl px-4 py-14 md:px-6">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1.2fr]">
          <div>
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-mist">
              دار خياطة سعودية متخصصة في العبايات الفاخرة. نختار الأقمشة بأنفسنا،
              ونطرّز كل قطعة على مقاس صاحبتها في ورشتنا في {STORE.city}.
            </p>
          </div>

          <nav>
            <h3 className="font-kufi text-sm text-gold-200">تنقّلي</h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              {[
                { to: '/', label: 'الرئيسية' },
                { to: '/products', label: 'معرض العبايات' },
                { to: '/cart', label: 'سلة المشتريات' },
                { to: '/contact', label: 'تواصلي معنا' },
              ].map((item) => (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className="text-mist transition-colors hover:text-gold-200"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="font-kufi text-sm text-gold-200">تواصلي معنا</h3>
            <ul className="mt-4 space-y-3 text-sm text-mist">
              <li>
                <a
                  href={whatsappLink(WHATSAPP_GREETING)}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex items-center gap-2 transition-colors hover:text-gold-200"
                  dir="ltr"
                >
                  <WhatsAppIcon className="h-4 w-4 shrink-0" />
                  {STORE.whatsappDisplay}
                </a>
              </li>
              <li>
                <a
                  href={`https://instagram.com/${STORE.instagram}`}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex items-center gap-2 transition-colors hover:text-gold-200"
                  dir="ltr"
                >
                  <Instagram className="h-4 w-4 shrink-0" aria-hidden="true" />@{STORE.instagram}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${STORE.email}`}
                  className="flex items-center gap-2 transition-colors hover:text-gold-200"
                  dir="ltr"
                >
                  <Mail className="h-4 w-4 shrink-0" aria-hidden="true" />
                  {STORE.email}
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                {STORE.address}
              </li>
              <li className="flex items-start gap-2">
                <Clock className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                {STORE.hours}
              </li>
            </ul>
          </div>
        </div>

        <Ornament className="mt-12" />

        <p className="mt-6 text-center text-xs text-mist/80">
          © {new Date().getFullYear().toLocaleString('ar-SA', { useGrouping: false })}{' '}
          {STORE.name} — جميع الحقوق محفوظة
        </p>
      </div>
    </footer>
  )
}
