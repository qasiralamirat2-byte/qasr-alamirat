import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Check, Plus } from 'lucide-react'
import { WhatsAppIcon } from '@/components/Brand'
import type { Product } from '@/data/products'
import { productOrderMessage, useCart } from '@/lib/cart'
import { img, imgSrcSet } from '@/lib/images'
import { formatPrice, whatsappLink } from '@/lib/store'

export function ProductCard({
  product,
  eager = false,
}: {
  product: Product
  eager?: boolean
}) {
  const cart = useCart()
  const [size, setSize] = useState(product.sizes[Math.floor(product.sizes.length / 2)])
  const [color, setColor] = useState(product.colors[0].name)
  const [justAdded, setJustAdded] = useState(false)

  const handleAdd = () => {
    cart.add({ productId: product.id, size, color, quantity: 1 })
    setJustAdded(true)
    window.setTimeout(() => setJustAdded(false), 1800)
  }

  return (
    <article className="group panel flex flex-col overflow-hidden rounded-2xl transition-[transform,box-shadow] duration-500 hover:-translate-y-1 hover:shadow-lift">
      <div className="relative overflow-hidden">
        <Link
          to="/products/$productId"
          params={{ productId: product.id }}
          aria-label={product.name}
          className="block"
        >
          <img
            src={img(product.image, 520, 690)}
            srcSet={imgSrcSet(product.image, 520, 690)}
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 45vw, 30vw"
            alt={`${product.name} — ${product.tagline}`}
            width={520}
            height={690}
            loading={eager ? 'eager' : 'lazy'}
            className="aspect-3/4 w-full object-cover transition-transform duration-700 ease-[var(--ease-silk)] group-hover:scale-[1.04]"
          />
          <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-transparent opacity-80" />
        </Link>

        {product.badge && (
          <span className="absolute top-3 start-3 rounded-full border border-gold-300/50 bg-ink/80 px-3 py-1 font-kufi text-[0.65rem] text-gold-200 backdrop-blur">
            {product.badge}
          </span>
        )}

        <span className="absolute bottom-3 end-3 rounded-full bg-wine-900/85 px-3 py-1 font-kufi text-xs text-gold-200 backdrop-blur">
          {product.category}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-4 p-5">
        <div>
          <Link to="/products/$productId" params={{ productId: product.id }}>
            <h3 className="font-display text-xl text-sand transition-colors group-hover:text-gold-200">
              {product.name}
            </h3>
          </Link>
          <p className="mt-1 text-sm leading-relaxed text-mist">{product.tagline}</p>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="font-kufi text-lg text-gold-200">{formatPrice(product.price)}</span>
          {product.wasPrice && (
            <span className="text-sm text-mist line-through">
              {formatPrice(product.wasPrice)}
            </span>
          )}
        </div>

        <div>
          <p className="mb-2 font-kufi text-[0.7rem] text-mist">المقاس</p>
          <div className="flex flex-wrap gap-2">
            {product.sizes.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setSize(option)}
                aria-pressed={size === option}
                className={`h-9 min-w-9 rounded-md border px-2 font-kufi text-sm transition-colors ${
                  size === option
                    ? 'border-gold-300 bg-gold-400/15 text-gold-100'
                    : 'border-gold-500/25 text-mist hover:border-gold-400/60 hover:text-sand'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 font-kufi text-[0.7rem] text-mist">
            اللون: <span className="text-sand">{color}</span>
          </p>
          <div className="flex flex-wrap gap-2.5">
            {product.colors.map((option) => (
              <button
                key={option.name}
                type="button"
                onClick={() => setColor(option.name)}
                title={option.name}
                aria-label={option.name}
                aria-pressed={color === option.name}
                className={`h-8 w-8 rounded-full border transition-transform hover:scale-110 ${
                  color === option.name
                    ? 'border-gold-300 ring-2 ring-gold-400/40 ring-offset-2 ring-offset-night'
                    : 'border-gold-500/30'
                }`}
                style={{ backgroundColor: option.hex }}
              />
            ))}
          </div>
        </div>

        <div className="mt-auto flex flex-col gap-2 pt-1">
          <button
            type="button"
            onClick={handleAdd}
            className="flex items-center justify-center gap-2 rounded-full border border-gold-400/50 bg-gold-400/10 py-3 font-kufi text-sm text-gold-100 transition-colors hover:bg-gold-400/20"
          >
            {justAdded ? (
              <>
                <Check className="h-4 w-4" aria-hidden="true" />
                أُضيفت إلى السلة
              </>
            ) : (
              <>
                <Plus className="h-4 w-4" aria-hidden="true" />
                أضيفي إلى السلة
              </>
            )}
          </button>

          <a
            href={whatsappLink(productOrderMessage(product, size, color))}
            target="_blank"
            rel="noreferrer noopener"
            className="flex items-center justify-center gap-2 rounded-full bg-[#1f6b4f] py-3 font-kufi text-sm text-white transition-colors hover:bg-[#248059]"
          >
            <WhatsAppIcon className="h-4 w-4" />
            اطلبيها عبر واتساب
          </a>
        </div>
      </div>
    </article>
  )
}
