import { useEffect, useState } from 'react'
import { Link, useRouterState } from '@tanstack/react-router'
import { Menu, ShoppingBag, Truck, X } from 'lucide-react'
import { Logo, WhatsAppIcon } from '@/components/Brand'
import { useCart } from '@/lib/cart'
import { STORE, formatPrice, whatsappLink, WHATSAPP_GREETING } from '@/lib/store'

const NAV = [
  { to: '/', label: 'الرئيسية' },
  { to: '/products', label: 'المعرض' },
  { to: '/ai', label: 'استوديو AI' },
  { to: '/cart', label: 'السلة' },
  { to: '/contact', label: 'تواصلي معنا' },
] as const

export function Header() {
  const { count, openDrawer, ready } = useCart()
  const [menuOpen, setMenuOpen] = useState(false)
  const pathname = useRouterState({ select: (state) => state.location.pathname })

  useEffect(() => {
    setMenuOpen(false)
  }, [pathname])

  return (
    <header className="sticky top-0 z-40">
      <div className="border-b border-gold-500/20 bg-wine-950/90 backdrop-blur">
        <p className="mx-auto flex max-w-7xl items-center justify-center gap-2 px-4 py-2 text-center text-[0.7rem] text-gold-200/90 md:text-xs">
          <Truck className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          توصيل مجاني داخل المملكة للطلبات من {formatPrice(STORE.freeShippingFrom)} · خياطة وتقصير مجاني
        </p>
      </div>

      <div className="border-b border-gold-500/25 bg-ink/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 md:px-6">
          <Link to="/" aria-label={STORE.name} className="shrink-0">
            <Logo compact />
          </Link>

          <nav className="ms-auto hidden items-center gap-7 md:flex">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="group relative font-kufi text-sm text-sand/85 transition-colors hover:text-gold-200"
                activeProps={{ className: 'text-gold-200' }}
                activeOptions={{ exact: item.to === '/' }}
              >
                {item.label}
                <span className="gold-rule absolute -bottom-1.5 start-0 h-px w-0 transition-[width] duration-300 group-hover:w-full" />
              </Link>
            ))}
          </nav>

          <div className="ms-auto flex items-center gap-2 md:ms-0">
            <a
              href={whatsappLink(WHATSAPP_GREETING)}
              target="_blank"
              rel="noreferrer noopener"
              className="hidden items-center gap-2 rounded-full border border-gold-400/40 px-4 py-2 font-kufi text-xs text-gold-200 transition-colors hover:border-gold-300 hover:bg-gold-400/10 sm:flex"
            >
              <WhatsAppIcon className="h-4 w-4" />
              واتساب
            </a>

            <button
              type="button"
              onClick={openDrawer}
              aria-label="عرض سلة المشتريات"
              className="relative rounded-full border border-gold-400/40 p-2.5 text-gold-200 transition-colors hover:border-gold-300 hover:bg-gold-400/10"
            >
              <ShoppingBag className="h-5 w-5" aria-hidden="true" />
              {ready && count > 0 && (
                <span className="absolute -top-1.5 -end-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-gold-400 px-1 text-[0.65rem] font-bold text-wine-950">
                  {count.toLocaleString('ar-SA')}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setMenuOpen((open) => !open)}
              aria-label={menuOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
              aria-expanded={menuOpen}
              className="rounded-full border border-gold-400/40 p-2.5 text-gold-200 md:hidden"
            >
              {menuOpen ? (
                <X className="h-5 w-5" aria-hidden="true" />
              ) : (
                <Menu className="h-5 w-5" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>

        {menuOpen && (
          <nav className="border-t border-gold-500/20 bg-ink/95 px-4 pb-4 md:hidden">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="block border-b border-gold-500/10 py-3 font-kufi text-sand/90"
                activeProps={{ className: 'text-gold-200' }}
                activeOptions={{ exact: item.to === '/' }}
              >
                {item.label}
              </Link>
            ))}
            <a
              href={whatsappLink(WHATSAPP_GREETING)}
              target="_blank"
              rel="noreferrer noopener"
              className="mt-4 flex items-center justify-center gap-2 rounded-full bg-[#1f6b4f] py-3 font-kufi text-sm text-white"
            >
              <WhatsAppIcon className="h-4 w-4" />
              اطلبي عبر واتساب
            </a>
          </nav>
        )}
      </div>
    </header>
  )
}
