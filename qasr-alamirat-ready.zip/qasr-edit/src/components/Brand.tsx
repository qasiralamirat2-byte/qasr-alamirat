import { STORE } from '@/lib/store'

/** Pointed-arch monogram drawn as SVG so it stays crisp at any size. */
export function Crest({ className = 'h-11 w-11' }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" aria-hidden="true" className={className}>
      <defs>
        <linearGradient id="crest-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#8f6b2b" />
          <stop offset="38%" stopColor="#f6ead0" />
          <stop offset="70%" stopColor="#cfa957" />
          <stop offset="100%" stopColor="#8f6b2b" />
        </linearGradient>
      </defs>
      <path
        d="M32 3 L57 17 V47 L32 61 L7 47 V17 Z"
        fill="none"
        stroke="url(#crest-gold)"
        strokeWidth="1.6"
      />
      {/* mihrab arch */}
      <path
        d="M32 16c-7 0-11 5-11 11v18h22V27c0-6-4-11-11-11Z"
        fill="none"
        stroke="url(#crest-gold)"
        strokeWidth="1.8"
      />
      <path d="M32 16v29" stroke="url(#crest-gold)" strokeWidth="0.8" opacity="0.7" />
      {/* crown */}
      <path
        d="M24 13 27 8 32 12 37 8 40 13"
        fill="none"
        stroke="url(#crest-gold)"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <circle cx="32" cy="27" r="2.4" fill="url(#crest-gold)" />
      <path d="M21 45h22" stroke="url(#crest-gold)" strokeWidth="1.4" />
    </svg>
  )
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <Crest className={compact ? 'h-9 w-9' : 'h-12 w-12'} />
      <span className="flex flex-col leading-none">
        <span
          className={`gold-text font-display font-bold ${compact ? 'text-xl' : 'text-2xl md:text-3xl'}`}
        >
          {STORE.name}
        </span>
        <span className="mt-1 font-kufi text-[0.6rem] text-mist/80 md:text-[0.68rem]">
          {STORE.nameLatin}
        </span>
      </span>
    </span>
  )
}

/** Ornamental gold divider used between sections. */
export function Ornament({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-3 ${className}`} aria-hidden="true">
      <span className="gold-rule h-px w-16 md:w-28" />
      <svg viewBox="0 0 24 24" className="h-4 w-4 text-gold-400">
        <path
          d="M12 2 15 12 12 22 9 12Z"
          fill="currentColor"
          opacity="0.9"
        />
        <path d="M2 12 12 9.5 22 12 12 14.5Z" fill="currentColor" opacity="0.55" />
      </svg>
      <span className="gold-rule h-px w-16 md:w-28" />
    </div>
  )
}

export function WhatsAppIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm0 18.13h-.01a8.23 8.23 0 0 1-4.19-1.15l-.3-.18-3.12.82.84-3.04-.2-.31a8.22 8.22 0 0 1-1.26-4.36c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.69 8.21-8.24 8.21Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-2-1.23-.74-.66-1.24-1.47-1.38-1.72-.15-.25-.02-.39.11-.51.11-.11.25-.29.37-.43.13-.15.17-.25.25-.42.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.41-.56-.42h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.72 2.63 4.17 3.69.58.25 1.04.4 1.39.51.59.19 1.12.16 1.55.1.47-.07 1.47-.6 1.68-1.19.21-.58.21-1.08.14-1.19-.06-.1-.23-.17-.48-.29Z" />
    </svg>
  )
}
