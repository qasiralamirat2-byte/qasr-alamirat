export type ProductColor = {
  name: string
  hex: string
}

export type Product = {
  id: string
  sku: string
  name: string
  tagline: string
  description: string
  price: number
  wasPrice?: number
  image: string
  fabric: string
  care: string
  category: 'سهرة' | 'مطرزة' | 'يومي' | 'كلاسيك'
  sizes: Array<string>
  colors: Array<ProductColor>
  badge?: string
  featured?: boolean
}

export const SIZE_GUIDE: Array<{ size: string; height: string; shoulder: string }> = [
  { size: '52', height: '١٥٠ – ١٥٥ سم', shoulder: '٣٨ سم' },
  { size: '54', height: '١٥٥ – ١٦٠ سم', shoulder: '٤٠ سم' },
  { size: '56', height: '١٦٠ – ١٦٥ سم', shoulder: '٤٢ سم' },
  { size: '58', height: '١٦٥ – ١٧٠ سم', shoulder: '٤٤ سم' },
  { size: '60', height: '١٧٠ – ١٧٥ سم', shoulder: '٤٦ سم' },
]

const products: Array<Product> = [
  {
    id: 'laylat-al-amir',
    sku: 'QA-1041',
    name: 'عباية ليلة الأمير',
    tagline: 'مخمل عنابي وتطريز ذهبي يدوي',
    description:
      'عباية من المخمل الإيطالي بلون العنابي الغامق، مطرزة يدويًا بخيوط الذهب على الصدر والأكمام بنقشٍ مستوحى من زخارف القصور. تُفتح من الأمام بسحّاب مخفي، ومبطنة من الداخل بحرير ناعم يحفظ انسدال القماش.',
    price: 1290,
    wasPrice: 1550,
    image: 'abaya-laylat-al-amir.png',
    fabric: 'مخمل إيطالي · بطانة حرير',
    care: 'تنظيف جاف فقط',
    category: 'سهرة',
    sizes: ['54', '56', '58', '60'],
    colors: [
      { name: 'عنابي ملكي', hex: '#5e1628' },
      { name: 'أسود ليلي', hex: '#14100f' },
    ],
    badge: 'الأكثر طلبًا',
    featured: true,
  },
  {
    id: 'sundus',
    sku: 'QA-1072',
    name: 'عباية سُندس',
    tagline: 'كيمونو مفتوح بتطريز نباتي ذهبي',
    description:
      'عباية كيمونو مفتوحة بقَصّة واسعة، يمتد عليها تطريز نباتي ذهبي من طرف الكم إلى الذيل. تأتي مع فستان داخلي عنابي بحزام رفيع، لتُلبس معًا في المناسبات أو منفصلين في اليوم العادي.',
    price: 1640,
    image: 'abaya-sundus.png',
    fabric: 'كريب ياباني مطرز · فستان داخلي ساتان',
    care: 'تنظيف جاف · كي بحرارة منخفضة من الداخل',
    category: 'مطرزة',
    sizes: ['54', '56', '58'],
    colors: [
      { name: 'أسود وذهبي', hex: '#191313' },
      { name: 'عنابي وذهبي', hex: '#45101f' },
    ],
    badge: 'إصدار محدود',
    featured: true,
  },
  {
    id: 'taj-al-dhahab',
    sku: 'QA-1058',
    name: 'عباية تاج الذهب',
    tagline: 'أكمام مزخرفة بخيط الزري',
    description:
      'قَصّة مستقيمة بلون الأسود العميق، تتوّجها أكمام مزخرفة بخيط الزري الذهبي مع شريط رفيع عند الرقبة. خفيفة على الكتف رغم غنى التطريز، ومناسبة للعزائم والمناسبات النهارية.',
    price: 980,
    image: 'abaya-taj-al-dhahab.png',
    fabric: 'نِدا كوري مطرز',
    care: 'غسيل يدوي بارد أو تنظيف جاف',
    category: 'مطرزة',
    sizes: ['52', '54', '56', '58', '60'],
    colors: [
      { name: 'أسود مطفي', hex: '#14100f' },
      { name: 'كحلي داكن', hex: '#1b2133' },
    ],
    featured: true,
  },
  {
    id: 'yaqut',
    sku: 'QA-1033',
    name: 'عباية ياقوت',
    tagline: 'لفّة أمامية بحزام عريض',
    description:
      'عباية بلفّة أمامية وحزام عريض من القماش نفسه يرسم الخصر بلا ضيق. لونها ياقوتي عنابي يميل للحمرة تحت الضوء، وقماشها كريب سادة يمنحها انسدالًا هادئًا مع الحركة.',
    price: 870,
    image: 'abaya-yaqut.png',
    fabric: 'كريب معتّم ثقيل',
    care: 'غسيل آلة على برنامج لطيف ٣٠°',
    category: 'كلاسيك',
    sizes: ['52', '54', '56', '58'],
    colors: [
      { name: 'ياقوتي', hex: '#7d1e35' },
      { name: 'زيتي غامق', hex: '#31392b' },
    ],
    featured: true,
  },
  {
    id: 'naseem-al-harir',
    sku: 'QA-1015',
    name: 'عباية نسيم الحرير',
    tagline: 'سادة بأكمام واسعة منسدلة',
    description:
      'العباية اليومية التي لا تُخطئ: كريب حرير أسود بقَصّة مستقيمة وأكمام واسعة تنسدل بهدوء. بلا أي زخرفة، لتكون الأساس الذي تُبنى عليه بقية القطع في الخزانة.',
    price: 590,
    image: 'abaya-naseem-al-harir.png',
    fabric: 'كريب حرير مخلوط',
    care: 'غسيل آلة على برنامج لطيف ٣٠°',
    category: 'يومي',
    sizes: ['52', '54', '56', '58', '60'],
    colors: [
      { name: 'أسود ليلي', hex: '#14100f' },
      { name: 'رمادي دخاني', hex: '#4a4744' },
      { name: 'عنابي غامق', hex: '#45101f' },
    ],
    badge: 'قطعة أساسية',
  },
  {
    id: 'hams-al-anbar',
    sku: 'QA-1024',
    name: 'عباية همس العنبر',
    tagline: 'شمبانيا هادئة بحزام رفيع',
    description:
      'لون الشمبانيا الدافئ مع خطوط ساتان بنفس الدرجة على الأكمام والحاشية، وحزام رفيع يُعقد عند الخصر. أنسب ما تُلبس في اللقاءات الصباحية وحفلات الشاي.',
    price: 740,
    image: 'abaya-hams-al-anbar.png',
    fabric: 'نِدا ناعم · تفاصيل ساتان',
    care: 'تنظيف جاف مُستحسن',
    category: 'كلاسيك',
    sizes: ['54', '56', '58'],
    colors: [
      { name: 'شمبانيا', hex: '#c8ab84' },
      { name: 'بيج رملي', hex: '#b39a7c' },
    ],
  },
  {
    id: 'zilal-al-layl',
    sku: 'QA-1067',
    name: 'عباية ظلال الليل',
    tagline: 'بليسيه دقيق يتحرك مع الضوء',
    description:
      'تنورة بليسيه دقيقة تتحرك مع كل خطوة وتلتقط الضوء بانعكاسات ناعمة. الجزء العلوي سادة لتبقى القَصّة متوازنة، والقماش خفيف لا يحتاج كيًّا.',
    price: 820,
    image: 'abaya-zilal-al-layl.png',
    fabric: 'شيفون بليسيه مبطّن',
    care: 'غسيل يدوي بارد · تُعلّق لتجف',
    category: 'سهرة',
    sizes: ['54', '56', '58', '60'],
    colors: [
      { name: 'أسود ليلي', hex: '#14100f' },
      { name: 'عنابي غامق', hex: '#2e0813' },
    ],
  },
  {
    id: 'luluu',
    sku: 'QA-1049',
    name: 'عباية لؤلؤ',
    tagline: 'عاجي بأزرار وتفاصيل لؤلؤية',
    description:
      'عباية بلون العاج الفاتح، بصفٍّ من الأزرار اللؤلؤية الصغيرة من الأمام وتفاصيل خرز لؤلؤي على الأكمام. لونها الفاتح يجعلها مختارة العرائس وأمهاتهن في المناسبات النهارية.',
    price: 1120,
    image: 'abaya-luluu.png',
    fabric: 'كريب مطفي · خرز لؤلؤي مخيط يدويًا',
    care: 'تنظيف جاف فقط',
    category: 'سهرة',
    sizes: ['52', '54', '56', '58'],
    colors: [
      { name: 'عاجي لؤلؤي', hex: '#e7e0d3' },
      { name: 'وردي باهت', hex: '#cdb0ab' },
    ],
  },
]

export const CATEGORIES = ['الكل', 'سهرة', 'مطرزة', 'كلاسيك', 'يومي'] as const
export type Category = (typeof CATEGORIES)[number]

export function productById(id: string) {
  return products.find((product) => product.id === id)
}

export default products
