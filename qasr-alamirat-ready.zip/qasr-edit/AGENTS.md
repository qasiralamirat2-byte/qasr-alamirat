# AGENTS.md

Architecture notes for **قصر الأميرات 
(Qasr Al Amirat)** — an Arabic, right-to-left abaya store on TanStack Start + Netlify.
Read `PLAN.md` for the numbered roadmap and continue from the first unfinished milestone.

## Stack

TanStack Start (React 19, TanStack Router file-based routing, SSR) · Tailwind CSS 4 ·
TypeScript strict · Netlify Image CDN · deployed on Netlify (`vite build` → `dist/client`).
There is no database, no payment gateway and no auth: orders are completed in WhatsApp.

## Directories

```
public/img/            Generated abaya photography (originals; never referenced directly)
scripts/
  generate-images.mjs  One-off image generation via Netlify AI Gateway (Gemini image model)
src/
  data/products.ts     The catalogue + SIZE_GUIDE + CATEGORIES. Single source of product truth.
  lib/store.ts         Shop settings: name, WhatsApp number, currency, address, hours.
  lib/cart.tsx         CartProvider context: lines, totals, drawer state, WhatsApp messages.
  lib/images.ts        img()/imgSrcSet() — always build image URLs through these.
  components/          Brand (Crest/Logo/Ornament/WhatsAppIcon), Header, Footer,
                       CartDrawer, ProductCard
  routes/__root.tsx    RTL document shell, Arabic fonts, header/footer, error + not-found screens
  routes/index.tsx     Homepage
  routes/products/     index.tsx (gallery), $productId.tsx (detail)
  routes/cart.tsx      Cart page
  styles.css           Tailwind v4 @theme tokens + gold-text/panel/arch/gold-rule utilities
```

## Conventions and non-obvious decisions

- **All copy is Arabic.** The document is `<html lang="ar" dir="rtl">`. Use logical Tailwind
  utilities only (`ms-`/`me-`, `ps-`/`pe-`, `start-`/`end-`, `text-start`) — never `left`/`right`.
  Never apply `letter-spacing` to Arabic text; it breaks letter joins.
- **Colour, type and shape come from tokens**, not ad-hoc values: `wine-*`, `gold-*`, `ink`,
  `night`, `sand`, `mist`, plus `font-display` (Amiri), `font-kufi` (Reem Kufi), `font-body`
  (Tajawal). The `arch` utility is the store's signature mihrab image frame; `panel` is the
  standard card surface; `gold-text` is the gradient wordmark treatment.
- **The WhatsApp number lives in exactly one place** — `STORE.whatsapp` in `src/lib/store.ts`,
  digits only. All order buttons derive from `whatsappLink()` plus a message builder in
  `src/lib/cart.tsx` (`productOrderMessage` for one abaya, `cart.orderMessage()` for the cart).
  Do not hardcode numbers or links in components.
- **Prices** are rendered with `formatPrice()` so digits are Arabic-Indic and the currency is
  consistent. Quantities and counters use `toLocaleString('ar-SA')` for the same reason.
- **Cart persistence** is `localStorage` under `qasr-al-amirat.cart.v1`. The provider starts
  empty and hydrates in an effect, exposing `ready` — gate any count/total UI on `ready` so
  server and client markup match. Saved lines whose product no longer exists are discarded.
- **Images**: `Product.image` stores only a filename. Components call `img(file, w, h)` /
  `imgSrcSet(...)`, which route through `/.netlify/images` (WebP, q=78). Run the site with
  `netlify dev` when checking images locally; plain `vite dev` does not serve that endpoint.
  Re-run `node scripts/generate-images.mjs` only when adding new products.
- **No blank screens**: the root route defines `errorComponent` and `notFoundComponent`, and
  the product loader throws `notFound()` for unknown ids. Keep that guarantee when adding routes.
- Adding an abaya means appending one entry to `src/data/products.ts` (with `sizes`, `colors`,
  `fabric`, `care`, `category`) and dropping its photo in `public/img` — no component edits.
