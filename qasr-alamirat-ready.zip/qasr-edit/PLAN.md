# قصر الأميرات — product roadmap

## Milestone 1 — Storefront (done)

Homepage with logo and crest, product gallery with filters and size guide, product detail
pages, working cart (drawer + `/cart` page, persisted in the browser), per-product WhatsApp
order buttons, homepage contact section, and full right-to-left Arabic UI in burgundy, black
and gold. Catalogue and shop settings are plain modules: `src/data/products.ts` and
`src/lib/store.ts`.

## Milestone 2 — Dedicated contact page

A `/contact` route holding the showroom address and map embed, opening hours, WhatsApp and
Instagram links, and an appointment request form (Netlify Forms). The header and footer
already link to it; every detail it needs is currently shown in the homepage contact band and
the footer.

## Milestone 3 — Order log

Persist submitted orders to a Netlify Database (Drizzle schema in `db/schema.ts`) at the moment
the WhatsApp message is opened, so the boutique has a record of carts, sizes and colours
independent of the chat history.

## Milestone 4 — Owner dashboard

Netlify Identity login for the shop owner, plus screens to add or retire abayas, adjust prices
and stock per size, and mark orders as confirmed or shipped — replacing edits to
`src/data/products.ts`.

## Milestone 5 — Growth

Arabic SEO metadata per product, structured data for Google Shopping, an Instagram feed
section, and a wishlist.
